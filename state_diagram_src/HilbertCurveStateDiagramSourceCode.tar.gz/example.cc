/*
 * Number of dimensions
 */
#define	DIM		5

#define NUMBITS 32
#define WORDBITS 32

/*
 * MUST be 32 bits
 */
typedef unsigned int	U_int;

typedef struct Hcode{
	U_int	hcode[DIM];
};

typedef Hcode Point;


/*============================================================================*/
/*                            H_encode  			      */
/*============================================================================*/
/* Converts a multiattribute point to a Hilbert code.
   Assumes that the values of p elements reside at the tops of their elements. */
Hcode H_encode(Point p)
{
	U_int mask = (U_int)1 << WORDBITS - 1, pval, element;
	Hcode h = {0};
	int i, j, state = 0;

	for (i = NUMBITS * DIM - DIM; i >=0; i -= DIM, mask >>= 1)
	{
		pval = 0;
		for (j = 0; j < DIM; j++) /* extract top bits from p */
			if (p.hcode[j] & mask)
				pval |= g_mask[j];
		/* add in DIM bits to hcode */
		element = i / WORDBITS;
		if (i % WORDBITS > WORDBITS - DIM)
		{
			h.hcode[element] |= g_curveND[state].value[pval] << i % WORDBITS;
			h.hcode[element + 1] |=
				g_curveND[state].value[pval] >> WORDBITS - i % WORDBITS;
		}
		else
			h.hcode[element] |=
				g_curveND[state].value[pval] << i - element * WORDBITS;

		state = g_curveND[state].state[pval];
	}
	return h;
}

/*============================================================================*/
/*                            H_decode					      */
/*============================================================================*/
/* Given a hilbert no, it works out what the corresponding coordinates are.
Coordinates are put in the Point structure (again with significant NUMBITS
at the top.
*/
Point H_decode (Hcode H)
{
	int i; /* needs to be able to == -1 for 'for' loop to terminate */
	U_int	mask = (U_int)1 << WORDBITS - 1, j, state = 0, hval, temp, element;
	Point p = {0};

	/* for each set of n bits, starting with the highest n */
	for (i = NUMBITS * DIM - DIM; i >= 0; i -= DIM, mask >>= 1)
	{
		element = i / WORDBITS;
		hval = H.hcode[element];
		if (i % WORDBITS > WORDBITS - DIM)
		{
			temp = H.hcode[element + 1];
			hval >>= i % WORDBITS;
			temp <<= WORDBITS - i % WORDBITS;
			hval |= temp;
		}
		else
			hval >>= i % WORDBITS;	/* hval is a DIM bit hcode */
		/* the & masks out spurious highbit values */
#if DIM < WORDBITS
			hval &= (1 << DIM) -1;
#endif

		temp = 	g2_curveND[state].value[hval];	/* temp is a DIM bit coord set */
		/* now distribute bits from j to x, y and z bottom to z etc */
/*		for (j = 0; j < DIM; j++)
			if (temp & g_mask[j])
				p.hcode[j] |= mask;*/

		for (j = DIM - 1; temp > 0; temp >>=1, j--)
			if (temp & 1)
				p.hcode[j] |= mask;

		state = g2_curveND[state].state[hval];
	}
	return p;
}
