/* copyright J.K.Lawder 2002 */
int createtable (ROW *, int *);
int printtable(ROW *, FILE *);