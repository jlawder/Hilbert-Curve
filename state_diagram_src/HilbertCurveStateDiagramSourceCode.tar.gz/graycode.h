/* copyright J.K.Lawder 2002 */
void GCF(int, int, int, unsigned int[]);
void X2GCF(int, int, int, unsigned int[]);