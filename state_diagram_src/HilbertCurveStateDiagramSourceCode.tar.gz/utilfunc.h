/* copyright J.K.Lawder 2002 */
char* int2bins(TWO_BYTES, int);